import java.util.*;

interface BillCalculator {
    double calculate(double amount);
}

class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        
        Map<String, Double> menu = new LinkedHashMap<>();
        menu.put("Pizza", 200.0);
        menu.put("Burger", 150.0);
        menu.put("Pasta", 180.0);
        menu.put("Sandwich", 100.0);
        menu.put("Coffee", 80.0);

        System.out.println("------ FOOD MENU ------");
        menu.forEach((item, price) ->
                System.out.println(item + " : Rs." + price));

       
        List<Double> orders = new ArrayList<>();

        BillCalculator itemTotal = amount -> amount;

        char choice = 'y';

        do {
            System.out.print("\nEnter food item: ");
            String item = sc.next();

            if (!menu.containsKey(item)) {
                System.out.println("Item not found! Try again.");
                continue;
            }

            System.out.print("Enter quantity: ");
            int qty = sc.nextInt();

            double total = itemTotal.calculate(menu.get(item) * qty);
            orders.add(total);

            System.out.println("Added: " + item + " x " + qty + " = Rs." + total);

            System.out.print("Add more items? (y/n): ");
            choice = sc.next().charAt(0);

        } while (choice == 'y' || choice == 'Y');

        BillCalculator gst = amount -> amount + (amount * 0.05);

        BillCalculator discount = amount -> amount - (amount * 0.10);

        BillCalculator delivery = amount -> {
            if (amount < 500) {
                return amount + 50;
            } else {
                return amount;
            }
        };

        BillCalculator service = amount -> amount + (amount * 0.02);


        orders.forEach(order -> {

            double afterGST = gst.calculate(order);
            double afterDiscount = discount.calculate(afterGST);
            double afterDelivery = delivery.calculate(afterDiscount);
            double finalAmount = service.calculate(afterDelivery);

            System.out.println("\nOriginal Amount  : Rs." + order);
            System.out.println("After GST (5%)   : Rs." + afterGST);
            System.out.println("After Discount   : Rs." + afterDiscount);
            System.out.println("After Delivery   : Rs." + afterDelivery);
            System.out.println("Final Bill       : Rs." + finalAmount);
            System.out.println("-----------------------------");
        });

        sc.close();
    }
}