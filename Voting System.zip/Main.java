import java.util.Scanner;

class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of candidates: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        String[] candidates = new String[n];
        int[] votes = new int[n];

        // Input candidate names
        for (int i = 0; i < n; i++) {
            System.out.print("Enter name of candidate " + (i + 1) + ": ");
            candidates[i] = sc.nextLine();
            votes[i] = 0;
        }

        int choice;

        do {
            System.out.println("\n--- Voting System Menu ---");
            System.out.println("1. Cast Vote");
            System.out.println("2. View Results");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("\nCandidates List:");
                    for (int i = 0; i < n; i++) {
                        System.out.println((i + 1) + ". " + candidates[i]);
                    }

                    System.out.print("Enter candidate number to vote: ");
                    int voteChoice = sc.nextInt();

                    if (voteChoice >= 1 && voteChoice <= n) {
                        votes[voteChoice - 1]++;
                        System.out.println("Vote cast successfully!");
                    } else {
                        System.out.println("Invalid choice!");
                    }
                    break;

                case 2:
                    System.out.println("\n--- Voting Results ---");
                    for (int i = 0; i < n; i++) {
                        System.out.println(candidates[i] + " : " + votes[i] + " votes");
                    }

                    // Find winner
                    int maxVotes = votes[0];
                    int winnerIndex = 0;

                    for (int i = 1; i < n; i++) {
                        if (votes[i] > maxVotes) {
                            maxVotes = votes[i];
                            winnerIndex = i;
                        }
                    }

                    System.out.println("Winner: " + candidates[winnerIndex]);
                    break;

                case 3:
                    System.out.println("Exiting Voting System...");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 3);

        sc.close();
    }
}