import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int seats[] = new int[5];  

        for(int i=0;i<seats.length;i++) {
            System.out.println("Seat " + (i+1) + " is Available");
        }

        System.out.print("Enter seat number to book: ");
        int s = sc.nextInt();

        if(seats[s-1] == 0) {
            seats[s-1] = 1;
            System.out.println("Seat booked successfully");
        } 
        else {
            System.out.println("Seat already booked");
        }

        System.out.println("\nBooked Seats:");
        for(int i=0;i<seats.length;i++) {
            if(seats[i] == 1)
                System.out.println("Seat " + (i+1));
        }
    }
}