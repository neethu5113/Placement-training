import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String name[] = new String[10];
        int age[] = new int[10];
        String disease[] = new String[10];

        int count = 0, choice;

        do {
            System.out.println("\n1.Add 2.View 3.Search 4.Delete");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Name: ");
                name[count] = sc.next();
                System.out.print("Age: ");
                age[count] = sc.nextInt();
                System.out.print("Disease: ");
                disease[count] = sc.next();
                count++;
            }

            else if (choice == 2) {
                for (int i = 0; i < count; i++) {
                    System.out.println(name[i] + " " + age[i] + " " + disease[i]);
                }
            }

            else if (choice == 3) {
                System.out.print("Enter name to search: ");
                String s = sc.next();
                for (int i = 0; i < count; i++) {
                    if (name[i].equals(s)) {
                        System.out.println(name[i] + " " + age[i] + " " + disease[i]);
                    }
                }
            }

            else if (choice == 4) {
                System.out.print("Enter name to delete: ");
                String d = sc.next();
                for (int i = 0; i < count; i++) {
                    if (name[i].equals(d)) {
                        name[i] = "Deleted";
                    }
                }
            }

        } while (choice != 5);

        sc.close();
    }
}